import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { ProjectModule } from './project/project.module';
import { TasksComponent } from './tasks/tasks.component';
import { ProjectListComponent } from './project/project-list.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    TasksComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'welcome', component: WelcomeComponent },
      { path: 'projects', component: ProjectListComponent },
      { path: '', redirectTo: 'welcome', pathMatch: 'full' },
      { path: '**', redirectTo: 'welcome', pathMatch: 'full' }
    ]),
    ProjectModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
