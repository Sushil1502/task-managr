import { InMemoryDbService } from 'angular-in-memory-web-api';

import { Project } from './project';

export class ProjectData implements InMemoryDbService {

  createDb() {
    const projects: Project[] = [
      {
        'id': 1,
        'Project_ID': 1,
        'Project': 'Demo',
        'Start_Date': 'March 19, 2018',
        'End_Date': 'March 19, 2018',
        'Priority': 19.95,
      },
      {
        'id': 2,
        'Project_ID': 2,
        'Project': 'Demo',
        'Start_Date': 'March 19, 2018',
        'End_Date': 'March 19, 2018',
        'Priority': 19.95,
      },
      {
        'id': 3,
        'Project_ID': 3,
        'Project': 'Demo',
        'Start_Date': 'March 19, 2018',
        'End_Date': 'March 19, 2018',
        'Priority': 19.95,
      },
      {
        'id': 4,
        'Project_ID': 4,
        'Project': 'Demo',
        'Start_Date': 'March 19, 2018',
        'End_Date': 'March 19, 2018',
        'Priority': 19.95,
      },
      {
        'id': 5,
        'Project_ID': 5,
        'Project': 'Demo',
        'Start_Date': 'March 19, 2018',
        'End_Date': 'March 19, 2018',
        'Priority': 19.95,
      },
    ];
    return { projects };
  }
}
