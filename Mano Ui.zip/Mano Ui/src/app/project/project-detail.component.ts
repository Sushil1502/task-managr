import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Project } from './project';
import { ProjectService } from './project.service';

@Component({
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.css']
})
export class ProjectDetailComponent implements OnInit {
  pageTitle = 'Project Detail';
  errorMessage = '';
  project: Project | undefined;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private projectService: ProjectService) {
  }

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getProject(id);
    }
  }

  getProject(id: number) {
    this.projectService.getProject(id).subscribe(
      project => this.project = project,
      error => this.errorMessage = <any>error);
  }

  onBack(): void {
    this.router.navigate(['/projects']);
  }

}
