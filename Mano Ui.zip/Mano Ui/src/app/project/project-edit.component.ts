import { Component, OnInit, AfterViewInit, OnDestroy, ViewChildren, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators, FormControlName } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Observable, Subscription, fromEvent, merge } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import { Project } from './project';
import { ProjectService } from './project.service';

import { NumberValidators } from '../shared/number.validator';
import { GenericValidator } from '../shared/generic-validator';

@Component({
  templateUrl: './project-edit.component.html'
})
export class ProjectEditComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];

  pageTitle = 'Project Edit';
  errorMessage: string;
  projectForm: FormGroup;

  project: Project;
  private sub: Subscription;

  // Use with the generic validation message class
  displayMessage: { [key: string]: string } = {};
  private validationMessages: { [key: string]: { [key: string]: string } };
  private genericValidator: GenericValidator;

  get tags(): FormArray {
    return <FormArray>this.projectForm.get('tags');
  }

  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private projectService: ProjectService) {

    // Defines all of the validation messages for the form.
    // These could instead be retrieved from a file or database.
    this.validationMessages = {
      projectName: {
        required: 'Project name is required.',
        minlength: 'Project name must be at least three characters.',
        maxlength: 'Project name cannot exceed 50 characters.'
      },
      projectCode: {
        required: 'Project code is required.'
      },
      starRating: {
        range: 'Rate the project between 1 (lowest) and 5 (highest).'
      }
    };

    // Define an instance of the validator for use with this form,
    // passing in this form's set of validation messages.
    this.genericValidator = new GenericValidator(this.validationMessages);
  }

  ngOnInit(): void {
    this.projectForm = this.fb.group({
      projectName: ['', [Validators.required,
      Validators.minLength(3),
      Validators.maxLength(50)]],
      projectCode: ['', Validators.required],
      starRating: ['', NumberValidators.range(1, 5)],
      tags: this.fb.array([]),
      description: ''
    });

    // Read the project Id from the route parameter
    this.sub = this.route.paramMap.subscribe(
      params => {
        const id = +params.get('id');
        this.getProject(id);
      }
    );
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  ngAfterViewInit(): void {
    // Watch for the blur event from any input element on the form.
    // This is required because the valueChanges does not provide notification on blur
    const controlBlurs: Observable<any>[] = this.formInputElements
      .map((formControl: ElementRef) => fromEvent(formControl.nativeElement, 'blur'));

    // Merge the blur event observable with the valueChanges observable
    // so we only need to subscribe once.
    merge(this.projectForm.valueChanges, ...controlBlurs).pipe(
      debounceTime(800)
    ).subscribe(value => {
      this.displayMessage = this.genericValidator.processMessages(this.projectForm);
    });
  }

  addTag(): void {
    this.tags.push(new FormControl());
  }

  deleteTag(index: number): void {
    this.tags.removeAt(index);
    this.tags.markAsDirty();
  }

  getProject(id: number): void {
    this.projectService.getProject(id)
      .subscribe(
        (project: Project) => this.displayProject(project),
        (error: any) => this.errorMessage = <any>error
      );
  }

  displayProject(project: Project): void {
    if (this.projectForm) {
      this.projectForm.reset();
    }
    this.project = project;

    if (this.project.id === 0) {
      this.pageTitle = 'Add Project';
    } else {
      this.pageTitle = `Edit Project: ${this.project.Project}`;
    }

    // Update the data on the form
    this.projectForm.patchValue({
      projectName: this.project.Project,
      projectCode: this.project.Project_ID,
      // starRating: this.project.starRating,
      description: this.project.Priority
    });
    // this.projectForm.setControl('tags', this.fb.array(this.project.tags || []));
  }

  deleteProject(): void {
    if (this.project.id === 0) {
      // Don't delete, it was never saved.
      this.onSaveComplete();
    } else {
      if (confirm(`Really delete the project: ${this.project.Project}?`)) {
        this.projectService.deleteProject(this.project.id)
          .subscribe(
            () => this.onSaveComplete(),
            (error: any) => this.errorMessage = <any>error
          );
      }
    }
  }

  saveProject(): void {
    if (this.projectForm.valid) {
      if (this.projectForm.dirty) {
        const p = { ...this.project, ...this.projectForm.value };

        if (p.id === 0) {
          this.projectService.createProject(p)
            .subscribe(
              () => this.onSaveComplete(),
              (error: any) => this.errorMessage = <any>error
            );
        } else {
          this.projectService.updateProject(p)
            .subscribe(
              () => this.onSaveComplete(),
              (error: any) => this.errorMessage = <any>error
            );
        }
      } else {
        this.onSaveComplete();
      }
    } else {
      this.errorMessage = 'Please correct the validation errors.';
    }
  }

  onSaveComplete(): void {
    // Reset the form to clear the flags
    this.projectForm.reset();
    this.router.navigate(['/projects']);
  }
}
