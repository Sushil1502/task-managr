import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';

import { ProjectEditComponent } from './project-edit.component';

@Injectable({
  providedIn: 'root'
})
export class ProjectEditGuard implements CanDeactivate<ProjectEditComponent> {
  canDeactivate(component: ProjectEditComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.projectForm.dirty) {
      const projectName = component.projectForm.get('projectName').value || 'New Project';
      return confirm(`Navigate away and lose all changes to ${projectName}?`);
    }
    return true;
  }
}
