import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';

// Imports for loading & configuring the in-memory web api
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { ProjectData } from './project-data';

import { ProjectListComponent } from './project-list.component';
import { ProjectDetailComponent } from './project-detail.component';
import { ProjectEditComponent } from './project-edit.component';
import { ProjectEditGuard } from './project-edit.guard';

@NgModule({
  imports: [
    SharedModule,
    ReactiveFormsModule,
    InMemoryWebApiModule.forRoot(ProjectData),
    RouterModule.forChild([
      { path: 'projects', component: ProjectListComponent },
      { path: 'projects/:id', component: ProjectDetailComponent },
      {
        path: 'projects/:id/edit',
        canDeactivate: [ProjectEditGuard],
        component: ProjectEditComponent
      }
    ])
  ],
  declarations: [
    ProjectListComponent,
    ProjectDetailComponent,
    ProjectEditComponent
  ]
})
export class ProjectModule { }
