/* Defines the product entity */
export interface Project {
  id: number;
  Project_ID: number;
  Project: string;
  Start_Date: string;
  End_Date: string;
  Priority: number;
  // price: number;
  // description: string;
  // starRating: number;
  // imageUrl: string;
}

