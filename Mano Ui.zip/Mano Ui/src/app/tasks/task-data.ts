import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Task}  from './task';
export class TaskData implements InMemoryDbService {
    createDb() {
        const tasks : Task[] = [
        {
            'Task_ID': 2,
            'Parent_ID': 1,
            'Project_ID': 1,
            'Task': 'Demo Task for testing',
            'Start_Date': 'March 19, 2019',
            'End_Date': 'March 19, 2019',
            'Priority': 12,
            'Status': 'InProgress', 
        },
        {
            'Task_ID': 3,
            'Parent_ID': 1,
            'Project_ID': 1,
            'Task': 'Demo2 Task for testing',
            'Start_Date': 'March 19, 2019',
            'End_Date': 'March 19, 2019',
            'Priority': 12,
            'Status': 'InProgress', 
        },
        {
            'Task_ID': 4,
            'Parent_ID': 1,
            'Project_ID': 1,
            'Task': 'Demo3 Task for testing',
            'Start_Date': 'March 19, 2019',
            'End_Date': 'March 19, 2019',
            'Priority': 12,
            'Status': 'InProgress', 
        },
        {
            'Task_ID': 5,
            'Parent_ID': 1,
            'Project_ID': 1,
            'Task': 'Demo4 Task for testing',
            'Start_Date': 'March 19, 2019',
            'End_Date': 'March 19, 2019',
            'Priority': 12,
            'Status': 'InProgress', 
        }
    ];
    return { tasks };
    }
}