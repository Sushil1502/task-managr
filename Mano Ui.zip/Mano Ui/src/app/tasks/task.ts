export interface Task {
    Task_ID: number;
    Parent_ID: number;
    Project_ID: number;
    Task: string;
    Start_Date: string;
    End_Date: string;
    Priority: number;
    Status: string;
}